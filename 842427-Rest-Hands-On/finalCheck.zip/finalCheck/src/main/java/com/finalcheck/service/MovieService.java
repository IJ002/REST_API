package com.finalcheck.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.finalcheck.entity.Movies;
import com.finalcheck.repository.MovieRepository;

@Service
public class MovieService {

	@Autowired
	MovieRepository repository;

	public List<Movies> findAll() {
		return repository.findAll();
	}

	public Movies save(Movies movie) {
		return repository.save(movie);
	}

	public Optional<Movies> findById(Integer id) {
		return repository.findById(id);
	}

	public void deleteById(Integer id) {
		repository.deleteById(id);
		
	}
}
