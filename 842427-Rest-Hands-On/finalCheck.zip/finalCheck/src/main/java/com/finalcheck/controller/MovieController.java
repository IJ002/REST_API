package com.finalcheck.controller;

import java.util.List;
import java.util.Optional;

import com.finalcheck.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.finalcheck.entity.Movies;

@RestController
@RequestMapping("/api")
public class MovieController {

	@Autowired
    MovieService service;

	@GetMapping("/add")
	public Movies addMovie(@RequestBody Movies movie) {
		return service.save(movie);
	}

	@GetMapping("/findById/{id}")
	public Optional<Movies> findById(@PathVariable("id") Integer id) {
		return service.findById(id);
	}

	@PostMapping("/edit/{id}")
	public Movies edit(@RequestBody Movies movie, @PathVariable("id") Integer id) {
		movie.setMovie_id(id);
		return service.save(movie);
	}

	@GetMapping("/showAllMovies")
	public List<Movies> showMovies() {
		return service.findAll();
	}
	
	@DeleteMapping("/delete/{id}")
	public Optional<Movies> deleteById(@PathVariable("id") Integer id){
		Optional<Movies> deletedMovie = findById(id);
		service.deleteById(id);
		return deletedMovie;
	}

}
