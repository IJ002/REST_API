package com.finalcheck.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.finalcheck.entity.Movies;

public interface MovieRepository extends JpaRepository<Movies, Integer> {

	
}
