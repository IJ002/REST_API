package com.CountryLogging;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountryLoggingApplicationTests {

	@Test
	void contextLoads() {
	}

}
