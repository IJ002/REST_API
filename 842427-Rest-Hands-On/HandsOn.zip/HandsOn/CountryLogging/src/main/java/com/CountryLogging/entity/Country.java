package com.CountryLogging.entity;

import java.util.logging.Logger;

public class Country {

	private Logger logger = Logger.getLogger("Country");

	private String code;
	private String name;

	public String getCode() {
		logger.info("Getting code: " + code);
		return code;
	}

	public void setCode(String code) {
		logger.info("Setting code: " + code);
		this.code = code;
	}

	public String getName() {
		logger.info("Getting name: " + name);
		return name;
	}

	public void setName(String name) {
		logger.info("Setting name: " + name);
		this.name = name;
	}

	@Override
	public String toString() {
		return "Country [code=" + code + ", name=" + name + "]";
	}

}
