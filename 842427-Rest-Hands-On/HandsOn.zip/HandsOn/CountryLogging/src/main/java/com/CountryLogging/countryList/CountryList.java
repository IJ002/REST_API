package com.CountryLogging.countryList;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.CountryLogging.entity.Country;

public class CountryList {

	private Logger logger = Logger.getLogger("CountryList");

	List<Country> countries = new ArrayList<>();

	public List<Country> getCountries() {
		logger.info("Getting from country list");
		return countries;
	}

	public void setCountries(List<Country> countries) {
		logger.info("Adding to country list");

		this.countries = countries;
	}

	@Override
	public String toString() {
		return "CountryList [countries=" + countries + "]";
	}

}
