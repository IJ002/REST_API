package com.CountryLogging;

import java.util.List;
import java.util.logging.Logger;

import com.CountryLogging.countryList.CountryList;
import com.CountryLogging.entity.Country;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class CountryLoggingApplication implements CommandLineRunner {

	private Logger logger = Logger.getLogger("CountryLoggingApplication");

	public static void main(String[] args) {

		SpringApplication.run(CountryLoggingApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		logger.info("Entering the run() method");

		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

		CountryList countries = context.getBean("countriesList", CountryList.class);
		List<Country> country = countries.getCountries();
		country.forEach(i -> {
			System.out.println(i);
		});

	}

}
