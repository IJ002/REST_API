package com.amith.cart.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.amith.cart.entity.Product;
import com.amith.cart.service.ProductService;

@RestController
@RequestMapping("/api")
public class ProductController {

	@Autowired
	private ProductService productService;

	@GetMapping("/add")
	public ModelAndView add() {
		return new ModelAndView("addproduct");

	}
	
	@GetMapping("/find")
	public ModelAndView find() {

		return new ModelAndView("find");

	}

	@GetMapping("/delete")
	public ModelAndView delete() {
		return new ModelAndView("deleteproduct");
	}

	@PostMapping("/addProduct")
	@ResponseStatus(code = HttpStatus.ACCEPTED)
	public Product addProduct(Product product) {
		return productService.save(product);
	}

	@DeleteMapping("/deleteProduct/{id}")
	@ResponseStatus(code = HttpStatus.FOUND)
	public ModelAndView addProduct(@PathVariable(value = "id") Integer id) {
		System.out.println("CALLED HERE");
		productService.delete(id);
		return new ModelAndView("homepage");

	}

	@GetMapping("/")
	public ModelAndView showHomepage() {
		return new ModelAndView("homepage");
	}

	@GetMapping("/products")
	@ResponseStatus(code = HttpStatus.FOUND)
	public List<Product> getAllProducts() {
		return productService.getAllProducts();
	}

	@PostMapping("/findById/{id}")
	@ResponseStatus(code = HttpStatus.FOUND)
	public Optional<Product> findById(@PathVariable("id") Integer id) {
		return 	productService.findById(id);
	}
}
